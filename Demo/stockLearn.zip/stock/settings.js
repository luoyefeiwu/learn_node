module.exports={
    cookieSecret: 'myStock', 
    db: 'stock', 
    host: 'localhost',
    url:'mongodb://localhost:27017/stock'
}